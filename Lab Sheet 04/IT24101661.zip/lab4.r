for(i in 1:10)
  print([i])
student<-c("ann","nimal")
j<-10
while (j<10) {
  print(j)
  j<-j+1
  
}